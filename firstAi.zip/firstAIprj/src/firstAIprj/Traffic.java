package firstAIprj;

public enum Traffic {
	LOW,
	NORMAL,
	HEAVY
}
